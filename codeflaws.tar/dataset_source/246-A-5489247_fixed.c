int main(int n, char *argv[]){scanf("%d",&n);while(n--)printf("%d ",n);return 0;
}
