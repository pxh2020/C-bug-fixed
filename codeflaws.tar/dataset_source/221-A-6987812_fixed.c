#include<stdio.h>

//f[x] = f[x0] + [x - x0]*f(x0,x1);

int temp;
int main(int argc, char *argv[]){
    int input,i=0;
    scanf("%d ",&input);
    printf("%d ",input);
    for(i = 1;i<input;i++){
        printf("%d ",i);
    }
    
    
return 0;
}
