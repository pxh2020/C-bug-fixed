#include<stdio.h>
int main(int argc, char *argv[]) {
	int n,i;
	scanf("%d",&n);
	printf("%d",n+n/2);
	return 0;
}
